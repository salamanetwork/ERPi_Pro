<script setup lang="ts">
import {useRoute} from 'vue-router'
import {onMounted,nextTick} from 'vue'
import CopyId from "./CopyId.vue"
import {computed,ref,watch} from 'vue'
import {api,allows,createRequest,type Workspace} from './api'
import {locale, message, t} from './i18n'
import TableToolbar from './TableToolbar.vue'
import BusinessChoice from './BusinessChoice.vue'
const props=defineProps<{module:string;workspace:Workspace}>()
const l=(en:string,ar:string)=>locale.value==='ar'?ar:en
const names:Record<string,[string,string]>={id:['ID','المعرّف'],portal:['Portal Account','حساب البوابة'],records:['Parties','الأطراف'],resources:['Resources and working hours','الموارد وساعات العمل'],appointments:['Appointments','المواعيد'],invoices:['Invoices','الفواتير'],receipts:['Receipts','الإيصالات'],party_type:['Party type','نوع الطرف'],name_en:['English name','الاسم الإنجليزي'],name_ar:['Arabic name','الاسم العربي'],phone:['Phone','الهاتف'],email:['Email','البريد'],identity_number:['Tax or national ID','الرقم الضريبي أو القومي'],address:['Address','العنوان'],notes:['Notes','ملاحظات'],active:['Active','نشط'],account_id:['Portal account ID','معرف حساب البوابة'],name:['Resource name','اسم المورد'],timezone:['Time zone','المنطقة الزمنية'],opens:['Opens','بداية الدوام'],closes:['Closes','نهاية الدوام'],slot_minutes:['Slot minutes','دقائق الموعد'],start:['Start (device local time)','البداية بتوقيت الجهاز'],currency:['Currency','العملة'],description:['Description','الوصف'],quantity:['Quantity','الكمية'],unit_price:['Unit price','سعر الوحدة'],tax_rate:['Tax %','نسبة الضريبة'],number:['Number','الرقم'],status:['Status','الحالة'],total:['Total','الإجمالي'],paid:['Paid','المدفوع'],amount:['Amount','المبلغ'],resource__name:['Resource','المورد'],invoice__number:['Invoice','الفاتورة'],invoice__currency:['Currency','العملة'],customer:['Customer','عميل'],supplier:['Supplier','مورد'],contact:['Contact','جهة اتصال'],both:['Customer and supplier','عميل ومورد'],scheduled:['Scheduled','مجدول'],confirmed:['Confirmed','مؤكد'],completed:['Completed','مكتمل'],cancelled:['Cancelled','ملغى'],no_show:['No show','لم يحضر'],draft:['Draft','مسودة'],issued:['Issued','صادرة'],partially_paid:['Partially paid','مدفوعة جزئياً'],void:['Void','ملغاة']}
const label=(s:string)=>names[s]?l(...names[s]):s
const sections=computed(()=>props.module==='parties'?['records']:props.module==='scheduling'?['resources','appointments']:['invoices','receipts'])
const section=ref(sections.value[0]!),site=ref<number>(),space=ref<number|null>(null),q=ref(''),size=ref(25),page=ref(1),count=ref(0),rows=ref<Record<string,any>[]>([]),error=ref(''),notice=ref(''),busy=ref(false),opened=ref(false)
const scope=computed(()=>({site_id:site.value,space_id:space.value}))
const params=computed(()=>'site_id='+site.value+(space.value?'&space_id='+space.value:''))
const sites=computed(()=>props.workspace.sites.filter(s=>s.active&&allows(props.workspace,props.module+'.view',s.id)))
const may=(a:string)=>allows(props.workspace,props.module+'.'+a,site.value)
const base=computed(()=>'/'+props.module+'/'),path=computed(()=>base.value+section.value)
const cols=computed(()=>({records:['id','portal','name_en','name_ar','party_type','email','active'],resources:['name','timezone','opens','closes','slot_minutes'],appointments:['resource__name','start','status'],invoices:['number','currency','total','paid','status'],receipts:['number','invoice__number','amount','invoice__currency']}[section.value]||[]))
const fields=computed(()=>({records:['name_en','name_ar','phone','email','identity_number','address','notes'],resources:['name','timezone','opens','closes','slot_minutes'],appointments:['start'],invoices:['currency']}[section.value]||[]))
const required=['name_en','name_ar','name','timezone','opens','closes','slot_minutes','start','currency']
const line=()=>({description:'',quantity:'1',unit_price:'0.00',tax_rate:'0'})
const defaults=()=>({party_type:'contact',active:true,timezone:'Asia/Dubai',opens:'09:00',closes:'17:00',slot_minutes:30,weekdays:[0,1,2,3,4],currency:'AED',party_id:null,resource_id:null,appointment_id:null,lines:[line()]}) as Record<string,any>
const form=ref(defaults()),payment=ref<number>(),payAmount=ref('')
type Detail={id:number;account_id?:string;account_label?:string;name_en:string;name_ar:string;sections:Record<string,Record<string,any>[]>}
const detail=ref<Detail>()
const groups:Record<string,[string,string]>={appointments:['Appointments','المواعيد'],invoices:['Invoices','الفواتير'],receipts:['Receipts','الإيصالات'],customers:['Customer records','سجلات العملاء'],suppliers:['Supplier records','سجلات الموردين'],sales:['Sales documents','مستندات البيع'],purchases:['Purchase orders','أوامر الشراء'],leads:['Leads','العملاء المحتملون'],portal:['Customer portal','بوابة العميل']}
const accountQ=ref(''),accounts=ref<{id:string;display_name:string;email:string}[]>([]),accountPage=ref(1),accountMore=ref(false)
let accountTicket=0
watch(accountQ,()=>accountPage.value=1)
watch([space,accountQ,accountPage,opened],async()=>{const ticket=++accountTicket;accounts.value=[];accountMore.value=false;if(!space.value||!opened.value||section.value!=='records')return;try{const d=await api<{results:typeof accounts.value;next:unknown}>('/platform/v1/identities?space_id='+space.value+'&status=active&page_size=10&page='+accountPage.value+'&q='+encodeURIComponent(accountQ.value));if(ticket===accountTicket){accounts.value=d.results;accountMore.value=!!d.next}}catch(e){if(ticket===accountTicket)error.value=message(e)}})
function fmt(v:unknown){return typeof v==='string'&&/^\d{4}-\d\d-\d\dT/.test(v)?new Date(v).toLocaleString(locale.value):v}
let detailTicket=0
async function inspect(id:number){const ticket=++detailTicket;detail.value=undefined;try{const result=await api<Detail>(path.value+'/'+id+'?'+params.value);if(ticket===detailTicket)detail.value=result}catch(e){error.value=message(e)}}
watch([scope,section],()=>{detailTicket++;detail.value=undefined})
let serial=0
let send=createRequest()
async function load(){const key=++serial;error.value='';rows.value=[];count.value=0;if(!site.value)return;try{const d=await api<{results:typeof rows.value;count:number;page:number}>(path.value+'?'+params.value+'&page='+page.value+'&page_size='+size.value+'&q='+encodeURIComponent(q.value));if(key===serial){rows.value=d.results;count.value=d.count;page.value=d.page}}catch(e){if(key===serial)error.value=message(e)}}
watch(()=>props.module,()=>{section.value=sections.value[0]!;site.value=sites.value[0]?.id},{immediate:true})
watch(site,()=>space.value=null)
watch([site,space,section],()=>{opened.value=false;payment.value=undefined;q.value='';form.value=defaults()})
watch([site,space,section,q,size],()=>page.value=1)
watch([path,site,space,q,size,page],load,{immediate:true})
function edit(row?:Record<string,any>){form.value={...defaults(),...row};opened.value=true;error.value=''}
async function submit(url:string,data:Record<string,any>){if(busy.value)return;busy.value=true;error.value=notice.value='';try{await send(url,{...data,...scope.value});send=createRequest();opened.value=false;payment.value=undefined;notice.value=t('Saved');await load()}catch(e){error.value=message(e)}finally{busy.value=false}}
function save(){const data={...form.value};if(section.value==='appointments')data.start=new Date(data.start).toISOString();if(section.value==='resources')data.slot_minutes=Number(data.slot_minutes);void submit(path.value,data)}
const lookup=(kind:string)=>base.value+'choices/'+kind+'?'+params.value
function stages(s:string){return s==='scheduled'?['confirmed','cancelled']:s==='confirmed'?['completed','cancelled','no_show']:[]}
const route = useRoute()
onMounted(async()=>{if(props.module==='billing_core'&&route.query.compose==='1'){
 const chosen=sites.value.find(s=>s.id===Number(route.query.site))||sites.value.find(s=>allows(props.workspace,'billing_core.manage',s.id))
 if(chosen){site.value=chosen.id;await nextTick();if(may('manage'))edit()}
}})
</script>
<template><section class="stack"><h1>{{label(section)}}</h1><nav class="actions"><button v-for="s in sections" :key="s" :aria-pressed="section===s" @click="section=s">{{label(s)}}</button></nav>
<div class="panel actions"><label>{{t('Site')}}<select v-model="site"><option v-for="s in sites" :key="s.id" :value="s.id">{{s.name}}</option></select></label><BusinessChoice v-model="space" :url="site?base+'choices/spaces?site_id='+site:''" :label="t('Publication space (optional)')"/></div>
<p v-if="error" role="alert" class="alert">{{error}}</p><p v-if="notice" role="status">{{notice}}</p>
<button v-if="may('manage')&&section!=='receipts'&&site" @click="edit()">{{t('New')}}</button>
<form v-validated-form v-if="opened" class="panel shared-form" @submit.prevent="save"><label v-for="f in fields" :key="f"><span>{{label(f)}} <FieldHint :label="label(f)" :required="required.includes(f)"/></span><input :data-field="f" v-model="form[f]" :required="required.includes(f)" :type="({email:'email',opens:'time',closes:'time',start:'datetime-local',slot_minutes:'number'} as Record<string,string>)[f]||'text'"></label>
<template v-if="section==='records'"><label v-if="space">{{t('Customer portal account')}}<input type="search" v-model="accountQ" :placeholder="t('Find by name or email')"><select v-model="form.account_id" data-field="account_id"><option :value="null">{{t('Unlink')}}</option><option v-if="form.account_id&&!accounts.some(a=>a.id===form.account_id)" :value="form.account_id">{{form.account_label||form.account_id}}</option><option v-for="a in accounts" :value="a.id">{{a.display_name}} · {{a.email}}</option></select><span><button type="button" :disabled="accountPage<=1" @click="accountPage--">‹</button><button type="button" :disabled="!accountMore" @click="accountPage++">›</button></span></label><label>{{label('party_type')}}<select v-model="form.party_type"><option v-for="k in ['customer','supplier','both','contact']" :value="k">{{label(k)}}</option></select></label><label><input type="checkbox" v-model="form.active">{{label('active')}}</label></template>
<fieldset v-if="section==='resources'"><legend>{{t('Working days')}}</legend><label v-for="(day,i) in (locale==='ar'?['الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت','الأحد']:['Mon','Tue','Wed','Thu','Fri','Sat','Sun'])"><input type="checkbox" v-model="form.weekdays" :value="i">{{day}}</label></fieldset>
<BusinessChoice v-if="['appointments','invoices'].includes(section)" v-model="form.party_id" required :url="lookup('parties')" :label="t('Party')"/>
<BusinessChoice v-if="section==='appointments'" v-model="form.resource_id" required :url="lookup('resources')" :label="label('resource__name')"/>
<template v-if="section==='invoices'"><BusinessChoice v-model="form.appointment_id" :url="form.party_id?lookup('appointments')+'&party_id='+form.party_id:''" :label="t('Appointment (optional)')"/><fieldset v-for="(r,i) in form.lines" :key="i"><legend>{{t('Line')}} {{Number(i)+1}}</legend><label v-for="k in Object.keys(line())"><span class="required-caption">{{label(k)}}</span><input :data-field="'lines.'+i+'.'+k" v-model="r[k]" required></label><button type="button" v-if="form.lines.length>1" @click="form.lines.splice(i,1)">−</button></fieldset><button type="button" @click="form.lines.push(line())">{{t('Add line')}}</button></template>
<div class="actions"><button :disabled="busy">{{t('Save')}}</button><button type="button" @click="opened=false">{{t('Cancel')}}</button></div></form>
<TableToolbar :page="page" :size="size" :count="count" :query="q" @page="page=$event" @size="size=$event" @search="q=$event"/>
<div class="panel table-panel"><table><thead><tr><th v-for="c in cols">{{label(c)}}</th><th>{{t('Actions')}}</th></tr></thead><tbody><tr v-for="r in rows" :key="r.id"><td v-for="c in cols"><CopyId v-if="c==='id'" :value="r.id"/><span v-else-if="c==='portal'">{{r.account_label}} <CopyId v-if="r.account_id" :value="r.account_id"/></span><template v-else>{{c==='status'||c==='party_type'?label(r[c]):c==='active'?(r[c]?t('Active'):t('Inactive')):fmt(r[c])}}</template></td><td><button v-if="section==='records'" @click="inspect(r.id)">{{t('Party 360°')}}</button><button v-if="may('manage')&&['records','resources'].includes(section)" @click="edit(r)">{{t('Edit')}}</button><template v-if="section==='appointments'&&may('manage')"><button v-for="s in stages(r.status)" :disabled="busy" @click="submit(path,{id:r.id,status:s,revision:r.revision})">{{label(s)}}</button></template>
<template v-if="section==='invoices'"><button v-if="r.status==='draft'&&may('issue')" :disabled="busy" @click="submit(path+'/'+r.id+'/issue',{revision:r.revision})">{{t('Issue')}}</button><button v-if="['draft','issued'].includes(r.status)&&may('issue')" :disabled="busy" @click="submit(path+'/'+r.id+'/void',{revision:r.revision})">{{label('void')}}</button><button v-if="['issued','partially_paid'].includes(r.status)&&may('pay')" @click="payment=r.id;payAmount=''">{{t('Record payment')}}</button><form v-validated-form v-if="payment===r.id" @submit.prevent="submit(path+'/'+r.id+'/pay',{revision:r.revision,amount:payAmount})"><label>{{label('amount')}}<input required inputmode="decimal" v-model="payAmount"></label><button :disabled="busy">{{t('Confirm')}}</button></form></template>
<a v-if="['invoices','receipts'].includes(section)" :href="'/api'+path+'/'+r.id+'/print?'+params+'&lang='+locale" target="_blank" rel="noopener">{{t('Print')}}</a></td></tr></tbody></table></div><section v-if="detail" class="panel"><header class="actions"><h2>{{locale==='ar'?detail.name_ar:detail.name_en}} · <bdi>360°</bdi> <CopyId :value="detail.id"/></h2><span v-if="detail.account_id">{{detail.account_label}} <CopyId :value="detail.account_id"/></span><button @click="detail=undefined">{{t('Close')}}</button></header><section v-for="(items,k) in detail.sections" :key="k"><h3>{{groups[k]?l(...groups[k]!):k}}</h3><p v-if="!items.length">{{t('No linked records')}}</p><ul v-else><li v-for="row in items">{{Object.values(row).map(fmt).join(' · ')}}</li></ul></section></section></section></template>
